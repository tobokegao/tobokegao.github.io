LM358N VST by DUSTINODELLOFFICIAL/SECRETCODE

This is gain plugin that applies op-amp style coloration to its input.
It is not a scientific model, but simulates many of the audio qualities of cheap, slow
op-amps (such as its namesake) typically used in old video game consoles and home computers. 

Processing includes:
	- Slew rate simulation/distortion
	- Saturation/non-linear amplification
	- Diode clipping simulation
	- Noise floor
	- Crossover distortion
	- DC filter "bass boost"

There is also a simple 1 pole adjustable lowpass included as this was a common
component of chip-amps to reduce aliasing from the sound hardware.

I created this primarily for chiptune mastering and it sounds particularly solid
on FM synth material. 32 and 64 bit Windows plugins are included.

This is the first serious bit of DSP programming I ever did. I may release the source
code sometime but don't hold your breath (it's a freak show of pseudo-object-oriented C 
glued to a C++ VST wrapper as I originally wrote this as a LADSPA plugin).

This software is public domain. Not thoroughly tested, but works well for me. No warranty.

